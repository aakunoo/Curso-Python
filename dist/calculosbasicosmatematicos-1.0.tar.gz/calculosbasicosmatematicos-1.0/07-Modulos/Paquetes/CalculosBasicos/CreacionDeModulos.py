def sumar(num1, num2):
    print(f"El resultado de la suma entre {num1} y {num2} es: {num1 + num2}")


def restar(num1, num2):
    print(f"El resultado de la resta entre {num1} y {num2} es: {num1 - num2}")


def multiplicar(num1, num2):
    print(f"El resultado de la multiplicacion entre {
          num1} y {num2} es: {num1 * num2}")
