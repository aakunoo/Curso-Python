from setuptools import setup

setup(
    name="calculosbasicosmatematicos",
    version="1.0",
    description="Paquete para calculos basicos, suma, resta y multiplicacion",
    author="Jeronimo",
    author_mail="jealvivi@gmail.com",
    url="",
    packages=["07-Modulos", "07-Modulos.Paquetes.CalculosBasicos"]
)
